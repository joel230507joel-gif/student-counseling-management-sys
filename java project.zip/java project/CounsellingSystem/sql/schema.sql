CREATE DATABASE IF NOT EXISTS counselling_db;
USE counselling_db;

CREATE TABLE counsellors (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    name           VARCHAR(100) NOT NULL,
    specialization VARCHAR(100)
);

CREATE TABLE students (
    id     INT AUTO_INCREMENT PRIMARY KEY,
    name   VARCHAR(100) NOT NULL,
    email  VARCHAR(100) UNIQUE,
    course VARCHAR(100)
);

CREATE TABLE counselling_sessions (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    student_id    INT NOT NULL,
    counsellor_id INT NOT NULL,
    session_date  DATE NOT NULL,
    notes         TEXT,
    FOREIGN KEY (student_id)    REFERENCES students(id)    ON DELETE CASCADE,
    FOREIGN KEY (counsellor_id) REFERENCES counsellors(id) ON DELETE CASCADE
);
