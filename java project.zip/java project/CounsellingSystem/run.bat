@echo off
setlocal
cd /d "%~dp0"
title Student Counselling Management System

echo ==========================================
echo Student Counselling Management System
echo ==========================================
echo Compiling latest Java source files...

if not exist out mkdir out
if exist out\Main.class del /q out\Main.class
javac -cp "lib\*" -d out src\*.java
if errorlevel 1 (
    echo.
    echo Compilation failed. Check the error messages above.
    pause
    exit /b 1
)

echo.
echo Running the updated application...
echo.
java -cp "out;lib\*" Main
pause
endlocal
