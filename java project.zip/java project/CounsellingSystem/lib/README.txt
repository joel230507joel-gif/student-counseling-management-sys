Download MySQL Connector/J from https://dev.mysql.com/downloads/connector/j/
Extract it and copy the mysql-connector-j-8.x.x.jar file into this lib folder.
