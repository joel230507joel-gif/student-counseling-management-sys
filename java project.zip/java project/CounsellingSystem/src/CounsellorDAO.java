import java.sql.*;
import java.util.*;

public class CounsellorDAO {

    public void addCounsellor(Counsellor c) throws SQLException {
        String sql = "INSERT INTO counsellors (name, specialization) VALUES (?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, c.getName());
            ps.setString(2, c.getSpecialization());
            ps.executeUpdate();
        }
    }

    public List<Counsellor> getAllCounsellors() throws SQLException {
        List<Counsellor> list = new ArrayList<>();
        String sql = "SELECT id, name, specialization FROM counsellors ORDER BY id";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(new Counsellor(rs.getInt("id"), rs.getString("name"),
                                        rs.getString("specialization")));
            }
        }
        return list;
    }

    public void deleteCounsellor(int id) throws SQLException {
        String sql = "DELETE FROM counsellors WHERE id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }
}
