import java.sql.SQLException;
import java.util.Map;
import java.util.Scanner;

public class Main {
    private static final Scanner sc = new Scanner(System.in);
    private static final StudentDAO studentDAO = new StudentDAO();
    private static final CounsellorDAO counsellorDAO = new CounsellorDAO();
    private static final SessionDAO sessionDAO = new SessionDAO();

    public static void main(String[] args) {
        while (true) {
            printMenu();
            String choice = sc.nextLine().trim();
            try {
                switch (choice) {
                    case "1" -> addStudent();
                    case "2" -> viewStudents();
                    case "3" -> updateStudent();
                    case "4" -> deleteStudent();
                    case "5" -> addCounsellor();
                    case "6" -> viewCounsellors();
                    case "7" -> bookSession();
                    case "8" -> sessionDAO.printSessionsWithDetails();
                    case "9" -> updateSession();
                    case "10" -> deleteSession();
                    case "11" -> printCounsellorReport();
                    case "12" -> deleteCounsellor();
                    case "0" -> { System.out.println("Goodbye!"); return; }
                    default -> System.out.println("Invalid option.");
                }
            } catch (SQLException e) {
                System.out.println("Database error: " + e.getMessage());
            } catch (IllegalArgumentException e) {
                System.out.println("Invalid input: " + e.getMessage());
            }
            System.out.println();
        }
    }

    private static void printMenu() {
        System.out.println("===== Student Counselling Management =====");
        System.out.println("1. Add student");
        System.out.println("2. View students");
        System.out.println("3. Update student");
        System.out.println("4. Delete student");
        System.out.println("5. Add counsellor");
        System.out.println("6. View counsellors");
        System.out.println("7. Book counselling session");
        System.out.println("8. View sessions (JOIN)");
        System.out.println("9. Update session");
        System.out.println("10. Delete session");
        System.out.println("11. Sessions per counsellor (GROUP BY/COUNT)");
        System.out.println("12. Delete counsellor");
        System.out.println("0. Exit");
        System.out.print("Choose: ");
    }

    private static int readInt(String prompt) {
        System.out.print(prompt);
        try {
            return Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Please enter a number.");
        }
    }


    private static String readValidName(String prompt) {
        while (true) {
            System.out.print(prompt);
            String name = sc.nextLine().trim();
            if (!name.isEmpty()) {
                return name;
            }
            System.out.println("Error: Name cannot be empty. Please enter a name.");
        }
    }

    private static String readValidEmail() {
        while (true) {
            System.out.print("Email: ");
            String email = sc.nextLine().trim();
            if (email.matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")) {
                return email;
            }
            System.out.println("Error: Invalid email address! Please enter a valid email (example: name@gmail.com).");
        }
    }

    private static void addStudent() throws SQLException {
        String name = readValidName("Name: ");
        String email = readValidEmail();
        System.out.print("Course: "); String course = sc.nextLine().trim();
        studentDAO.addStudent(new Student(0, name, email, course));
        System.out.println("Student saved to database.");
    }

    private static void viewStudents() throws SQLException {
        for (Student s : studentDAO.getAllStudents()) {
            System.out.println(s);
        }
    }

    private static void updateStudent() throws SQLException {
        int id = readInt("Student ID to update: ");
        String name = readValidName("New name: ");
        String email = readValidEmail();
        System.out.print("New course: "); String course = sc.nextLine().trim();
        boolean ok = studentDAO.updateStudent(new Student(id, name, email, course));
        System.out.println(ok ? "Student updated." : "No student with that ID.");
    }

    private static void deleteStudent() throws SQLException {
        int id = readInt("Student ID to delete: ");
        System.out.println(studentDAO.deleteStudent(id) ? "Student deleted." : "No student with that ID.");
    }

    private static void addCounsellor() throws SQLException {
        System.out.print("Name: ");           String name = sc.nextLine();
        System.out.print("Specialization: "); String spec = sc.nextLine();
        counsellorDAO.addCounsellor(new Counsellor(0, name, spec));
        System.out.println("Counsellor saved to database.");
    }

    private static void viewCounsellors() throws SQLException {
        for (Counsellor c : counsellorDAO.getAllCounsellors()) {
            System.out.println(c);
        }
    }

    private static void deleteCounsellor() throws SQLException {
        int id = readInt("Counsellor ID to delete: ");
        counsellorDAO.deleteCounsellor(id);
        System.out.println("Delete request completed. If the counsellor ID exists and is not in use, the counsellor was deleted.");
    }

    private static void bookSession() throws SQLException {
        System.out.println("--- Students ---");
        viewStudents();
        System.out.println("--- Counsellors ---");
        viewCounsellors();
        int studentId = readInt("Student ID: ");
        int counsellorId = readInt("Counsellor ID: ");
        System.out.print("Date (yyyy-mm-dd): "); String date = sc.nextLine();
        System.out.print("Notes: ");             String notes = sc.nextLine();
        sessionDAO.bookSession(studentId, counsellorId, date, notes);
        System.out.println("Session booked.");
    }

    private static void updateSession() throws SQLException {
        int id = readInt("Session ID to update: ");
        System.out.print("New date (yyyy-mm-dd): "); String date = sc.nextLine();
        System.out.print("New notes: ");             String notes = sc.nextLine();
        System.out.println(sessionDAO.updateSession(id, date, notes) ? "Session updated." : "No session with that ID.");
    }

    private static void deleteSession() throws SQLException {
        int id = readInt("Session ID to delete: ");
        System.out.println(sessionDAO.deleteSession(id) ? "Session deleted." : "No session with that ID.");
    }

    private static void printCounsellorReport() throws SQLException {
        Map<String, Integer> report = sessionDAO.countSessionsPerCounsellor();
        System.out.printf("%-25s %s%n", "Counsellor", "Sessions");
        for (Map.Entry<String, Integer> e : report.entrySet()) {
            System.out.printf("%-25s %d%n", e.getKey(), e.getValue());
        }
    }
}
