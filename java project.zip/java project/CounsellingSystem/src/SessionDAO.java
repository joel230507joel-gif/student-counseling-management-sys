import java.sql.*;
import java.util.*;

public class SessionDAO {

    public void bookSession(int studentId, int counsellorId, String date, String notes) throws SQLException {
        String sql = "INSERT INTO counselling_sessions (student_id, counsellor_id, session_date, notes) VALUES (?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            ps.setInt(2, counsellorId);
            ps.setDate(3, java.sql.Date.valueOf(date)); // format yyyy-MM-dd
            ps.setString(4, notes);
            ps.executeUpdate();
        }
    }

    // JOIN across three tables
    public void printSessionsWithDetails() throws SQLException {
        String sql = "SELECT cs.id, st.name AS student_name, c.name AS counsellor_name, " +
                     "cs.session_date, cs.notes " +
                     "FROM counselling_sessions cs " +
                     "JOIN students st ON cs.student_id = st.id " +
                     "JOIN counsellors c ON cs.counsellor_id = c.id " +
                     "ORDER BY cs.session_date";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            System.out.printf("%-4s %-20s %-20s %-12s %s%n", "ID", "Student", "Counsellor", "Date", "Notes");
            while (rs.next()) {
                System.out.printf("%-4d %-20s %-20s %-12s %s%n",
                        rs.getInt("id"), rs.getString("student_name"),
                        rs.getString("counsellor_name"), rs.getDate("session_date"),
                        rs.getString("notes"));
            }
        }
    }

    public boolean updateSession(int id, String date, String notes) throws SQLException {
        String sql = "UPDATE counselling_sessions SET session_date = ?, notes = ? WHERE id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setDate(1, java.sql.Date.valueOf(date));
            ps.setString(2, notes);
            ps.setInt(3, id);
            return ps.executeUpdate() > 0;
        }
    }

    public boolean deleteSession(int id) throws SQLException {
        String sql = "DELETE FROM counselling_sessions WHERE id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    // GROUP BY + COUNT
    public Map<String, Integer> countSessionsPerCounsellor() throws SQLException {
        Map<String, Integer> report = new LinkedHashMap<>();
        String sql = "SELECT c.name, COUNT(cs.id) AS total " +
                     "FROM counsellors c LEFT JOIN counselling_sessions cs ON c.id = cs.counsellor_id " +
                     "GROUP BY c.id, c.name ORDER BY total DESC";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                report.put(rs.getString("name"), rs.getInt("total"));
            }
        }
        return report;
    }
}
