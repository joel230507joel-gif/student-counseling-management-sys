public class Counsellor extends Person {
    private String specialization;

    public Counsellor(int id, String name, String specialization) {
        super(id, name);
        this.specialization = specialization;
    }

    public String getSpecialization() { return specialization; }

    @Override
    public String getRole() { return "Counsellor"; }

    @Override
    public String toString() {
        return super.toString() + " | " + specialization;
    }
}
