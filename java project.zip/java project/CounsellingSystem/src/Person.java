public abstract class Person {
    private int id;
    private String name;

    protected Person(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId()   { return id; }
    public String getName() { return name; }

    public abstract String getRole();   // each subclass must define this

    @Override
    public String toString() {
        return String.format("%-10s #%-4d %s", getRole(), id, name);
    }
}
