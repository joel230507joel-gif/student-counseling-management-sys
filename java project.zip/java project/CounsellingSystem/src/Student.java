public class Student extends Person {
    private String email;
    private String course;

    public Student(int id, String name, String email, String course) {
        super(id, name);
        this.email = email;
        this.course = course;
    }

    public String getEmail()  { return email; }
    public String getCourse() { return course; }

    @Override
    public String getRole() { return "Student"; }

    @Override
    public String toString() {
        return super.toString() + " | " + email + " | " + course;
    }
}
